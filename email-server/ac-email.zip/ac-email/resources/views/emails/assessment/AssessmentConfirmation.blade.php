@component('mail::message')
# Dear {{$name}},<br>
{{$body}}<br>

@component('mail::button', ['url' => $home_url])
Click to go NSL
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
