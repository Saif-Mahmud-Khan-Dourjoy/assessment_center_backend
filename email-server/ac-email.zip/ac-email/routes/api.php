<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix'=>'v1'], function(){
    Route::post('user-credential', "API\User\UserCredentialController@singleUserCredential");
    Route::post('bulk-entry-credential', "API\User\UserCredentialController@bulkEntryCredential");

    Route::post("students-result", "API\Result\StudentResultController@resultBroadcast");

    Route::post("assessment-info", "API\Assessment\StudentAssessmentController@assessmentInfo");
    Route::post("assessment-confirmation","API\Assessment\StudentAssessmentController@assessmentConfirmation"); 
});

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
