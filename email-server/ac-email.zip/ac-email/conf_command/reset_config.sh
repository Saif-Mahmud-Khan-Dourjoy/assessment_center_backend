#!/bin/sh
php artisan config:cache
php artisan config:clear
php artisan cache:clear
php artisan view:clear
composer dump-autoload
