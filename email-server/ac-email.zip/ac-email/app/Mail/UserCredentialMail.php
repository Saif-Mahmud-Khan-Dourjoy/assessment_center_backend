<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UserCredentialMail extends Mailable
{
    use Queueable, SerializesModels;

    private $credential;
    public $out;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($credential)
    {
       $this->credential = $credential;
       $this->out = new \Symfony\Component\Console\Output\ConsoleOutput();
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $this->out->writeln([
            'username'=> $this->credential['username'],
            'url'=>env('FRONT_END_HOME').'/login?username='.$this->credential['username'],
        ]);
        
        return $this->markdown('emails.user.credential',[
            'name'=>$this->credential['name'],
            'username'=> $this->credential['username'],
            'password'=> $this->credential['password'],
            'email'=>$this->credential['email'],
            'url'=>env('FRONT_END_HOME').'/login?username='.$this->credential['username'],
        ]);
    }

}
