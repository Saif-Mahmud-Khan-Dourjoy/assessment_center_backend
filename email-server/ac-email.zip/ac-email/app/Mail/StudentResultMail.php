<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class StudentResultMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $result_info;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($result_info)
    {
        $this->result_info=$result_info;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        // return $this->markdown('emails.result.StudentResult');
        return $this->markdown('emails.result.StudentResult', $this->result_info)
                    ->subject('Assessment Result');
    }
}
