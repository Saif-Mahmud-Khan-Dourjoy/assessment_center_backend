<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Mail;
use App\Mail\AssessmentMail;

class StudentAssessmentQueue implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $email_info;
    public $out;

    public $tries = 5;


    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($email_info)
    {
        $this->email_info = $email_info;
        $this->out= new \Symfony\Component\Console\Output\ConsoleOutput();
        $this->show();
    }

    public function show(){
        try{
            $this->out->writeln("Title     : ".$this->email_info['title']);
            $this->out->writeln("Body      : ".$this->email_info['body']);
            $this->out->writeln("Name      : ".$this->email_info['name']);
            $this->out->writeln("Email     : ".$this->email_info['email']);
        }catch(\Exception $e){
            $this->out->writeln("Unable to show email info! error: ".$e->getMessage());
        }
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $email = Mail::to($this->email_info['email'])->send(new AssessmentMail($this->email_info));
    }
}
