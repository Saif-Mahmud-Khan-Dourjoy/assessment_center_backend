<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Mail\UserCredentialMail;
use Illuminate\Support\Facades\Mail;
use \Symfony\Component\Console\Output\ConsoleOutput;

class UserCredentialQueue implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $credential;
    public $tries= 5;
    public $out;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($credential)
    {
        $this->credential = $credential;
        $this->out = new ConsoleOutput();
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Mail::to($this->credential['email'])->send(new UserCredentialMail($this->credential));
    }
}


