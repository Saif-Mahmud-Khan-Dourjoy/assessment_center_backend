<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use \Symfony\Component\Console\Output\ConsoleOutput;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Mail;
use App\Mail\StudentResultMail;

class StudentResultQueue implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $email_info;
    public $tries=5;
    public $out;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($result_info)
    {
        $this->email_info = $result_info;
        $this->out=new ConsoleOutput();
        $this->out->writeln("Student Result Controller!");
        // $this->show();
    }

    public function show(){
        $this->out->writeln("Question set title : ".$this->email_info['question_set_title']);
        $this->out->writeln("start_time         : ".$this->email_info['start_time']);
        $this->out->writeln("end time           : ".$this->email_info['end_time']);
        $this->out->writeln("assessment_time    : ".$this->email_info['assessment_time']);
        $this->out->writeln("total_mark         : ".$this->email_info['total_mark']);
        $this->out->writeln("Total Participant  : ".$this->email_info['number_of_participation']);
        $this->out->writeln("Institution Name   : ".$this->email_info['institute_name']);
        $this->out->writeln("total_time         : ".$this->email_info['total_time']);
        $this->out->writeln("NUmber of candidates: ".$this->email_info['question_set_title']);
        $this->out->writeln("NUmber of candidates: ".$this->email_info['question_set_title']);        

        $this->out->writeln("User email         : ".$this->email_info['user_email']);
        $this->out->writeln("Time Taken         : ".$this->email_info['time_taken']);
        $this->out->writeln("Marks              : ".$this->email_info['marks']);
        $this->out->writeln("First name         : ".$this->email_info['first_name']);
        $this->out->writeln("Last Name          : ".$this->email_info['last_name']);
        $this->out->writeln("Percentage         : ".$this->email_info['percentage']);
        $this->out->writeln("Position           : ".$this->email_info['position']);
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $email = Mail::to($this->email_info['user_email'])->send(new StudentResultMail($this->email_info));
    }
}
