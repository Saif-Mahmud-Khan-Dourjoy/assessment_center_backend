<?php

namespace App\Http\Controllers\API\User;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use App\Jobs\UserCredentialQueue;
use App\Mail\UserCredentialMail;
use Illuminate\Support\Facades\Mail;

class UserCredentialController extends Controller
{
    public $failedStatus = 500;
    public $successStatus = 200;
    public $invalidStatus =400;

    public $out;

    function __construct(){
        $this->out = new \Symfony\Component\Console\Output\ConsoleOutput();
    }

    public function  singleUserCredential(Request $request){
        try{
            $credential = [
                'email'=>$request['email'],
                'first_name'=>$request['first_name'],
                'last_name'=>$request['last_name'],
                'name'=>$request['first_name']." ".$request['last_name'],
                'username'=>$request['username'],
                'password'=>$request['password'],
                'delay'=>$request['delay'],
            ];
            // $users = User::all();
            // $this->out->writeln("Credential: ".$credential['email']);
            // Mail::to($credential['email'])->send(new UserCredentialMail($credential));
            // Mail::to("hemayet.nsl@gmail.com")->send(new UserCredentialMail($credential));
            UserCredentialQueue::dispatch($credential)->delay(now()->addSeconds($request['delay']));
            return response()->json(["success"=>true, "message"=>"User will get credential after a while."], $this->successStatus);
        }catch(\Exception $e){
            $this->out->writeln("Unable to send user-credential!, error: ".$e->getMessage());
            return response()->json(['success'=>false, "message"=>"Unable to send user credentials!", "error"=>$e->getMessage()], $this->failedStatus);
        }
    }

    public function bulkEntryCredential(Request $request){
        try{
            $this->out->writeln("Making job for bulk email!");
            $input = $request->all();
            $students = $input['students'];
            $delay = $input['delay'];
            foreach($students as $student){
                $this->out->writeln("Student:".$student['email']);
                $student['delay']=$delay;
                UserCredentialQueue::dispatch($student)->delay(now()->addSeconds($request['delay']));
            }
            return response()->json(['success'=>true, "message"=>"All the users will get their credentials one by one!"], $this->successStatus);
        }catch(\Exception $e){
            $this->out->writeln('There is a problem for emailing mass-students! error: '.$e->getMessage());
            return response()->json(['success'=>false, 'message'=>"There is a problem during bulk-email!", "error"=>$e->getMessage()], $this->failedStatus);
        }
    }
}