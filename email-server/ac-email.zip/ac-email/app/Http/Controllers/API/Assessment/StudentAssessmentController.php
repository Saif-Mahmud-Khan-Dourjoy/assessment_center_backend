<?php

namespace App\Http\Controllers\API\Assessment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Jobs\UserCredentialQueue;
use App\Mail\UserCredentialMail;
use App\Jobs\StudentAssessmentQueue;
use App\Jobs\AssessmentConfirmationQueue;
use Illuminate\Support\Facades\Mail;
use App\UserProfile;

class StudentAssessmentController extends Controller
{
    public $failedStatus=500;
    public $successStatus=200;
    public $invalidStatus=400;
    public  $out;

    public function __construct(){
        $this->out = new \Symfony\Component\Console\Output\ConsoleOutput();
    }

    public function assessmentInfo(Request $request){
        try{
            $this->out->writeln("Broadcasting Assessment Information...");
            $email_info=[
                'title'=>$request['title'],
                'body'=>$request['body'],
            ];
            $profiles = $request['profiles'];
            foreach($profiles as $profile){
                $email_info['name']=$profile['user_profile']['first_name']." ".$profile['user_profile']['last_name'];
                $email_info['email']=$profile['email'];
                $email_info['first_name']=$profile['user_profile']['first_name'];
                $email_info['last_name']=$profile['user_profile']['last_name'];
                try{
                    $this->out->writeln("*****************Dispatching job*****************");
                    StudentAssessmentQueue::dispatch($email_info)->delay(now()->addSeconds($request['delay']));
                    $this->out->writeln("*****************Job Dispatched******************");
                }catch(\Exception $e){
                    $this->out->writeln("Mailing to ".$email_info['email']." is Unsuccessful! error: ".$e->getMessage());
                }
            }
            return response()->json(['success'=>true, "message"=>"Assessment information will be notified soon!"], $this->successStatus);
        }catch(\Exception $e){
            $this->out->writeln("Unable to broadcast Assessment Info! Error: ".$e->getMessage());
            return response()->json(['success'=>false, "message"=>"There is a problem broadcasting Assessment info!", "error"=>$e->getMessage()], $this->failedStatus);
        }
    }

    public function assessmentConfirmation(Request $request){
        try{
            $this->out->writeln("Broadcasting Round Confirmation...");
            $home_url = $request['home_url'];
            $email_info=[
                'title'=>$request['title'],
                'body'=>$request['body'],
            ];
            // $candidates = $request['candidates'];
            $candidates = explode("|",$request['candidates']);
            foreach($candidates as $candidate){
                $profile = UserProfile::where();
                // $this->out->writeln("Profile: ".$profile);
                $email_info['name']=$profile['first_name']." ".$profile['last_name'];
                $email_info['email']=$profile['email'];
                $email_info['first_name']=$profile['first_name'];
                $email_info['last_name']=$profile['last_name'];
                $email_info['home_url']=$home_url."/login";
                try{
                    $this->out->writeln("*****************Dispatching job*****************");
                    AssessmentConfirmationQueue::dispatch($email_info)->delay(now()->addSeconds($request['delay']));
                    $this->out->writeln("*****************Job Dispatched******************");
                }catch(\Exception $e){
                    $this->out->writeln("Mailing to ".$email_info['email']." is Unsuccessful! error: ".$e->getMessage());
                }
            }
            return response()->json(['success'=>true, "message"=>"Assessment information will be notified soon!"], $this->successStatus);
        }catch(\Exception $e){
            $this->out->writeln("There is a problem Round Confirmation! error: ".$e->getMessage());
            return response()->json(['success'=>false, "message"=>"There is a problem broadcasting Round Confirmation!", "error"=>$e->getMessage()], $this->failedStatus);
        }
    }
}
