<?php

namespace App\Http\Controllers\API\Result;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use \Symfony\Component\Console\Output\ConsoleOutput;
use App\Jobs\StudentResultQueue;
use Carbon\Carbon;

class StudentResultController extends Controller
{
    public $successStatus=200;
    public $failedStatus=500;
    public $invalidStatus=400;
    public $out;

    function __construct(){
        $this->out= new ConsoleOutput();
        $this->out->writeln("Student result controller!");
    }

    public function resultBroadcast(Request $request){
        $this->out->writeln("Broadcasting result...");
        try{
            $question_set = $request['question_set'];
            $question_set_answers = $request['question_set_answers'];
            usort($question_set_answers, function($student1, $student2){
                return ($student1['total_mark'] < $student2['total_mark']) || ($student1['total_mark'] == $student2['total_mark'] && $student1['time_taken'] > $student2['time_taken']);
            });
            $institute_name = $request['institute_name'];       
            $st_time = Carbon::parse($question_set['start_time']);
            $end_time = Carbon::parse($question_set['end_time']);
            $email_info=[
                'question_set_title'=>trim($question_set['title']),
                'start_time'=>trim($st_time->toDayDateTimeString()),
                'end_time'=>trim($end_time->toDayDateTimeString()),
                'assessment_time'=>trim($question_set['assessment_time']),
                'total_mark'=>trim($question_set['total_mark']),
                'number_of_participation'=>sizeof($question_set_answers),
                'institute_name'=>trim($institute_name),
                'total_time'=>trim($question_set['assessment_time']),
            ];
            // $this->out->writeln("Email info: ".$email_info);
            $total_student=sizeof($question_set_answers);
            $total_mark = $question_set['total_mark'];
            for($rank=0, $position=0; $rank<$total_student;$rank++){
                $mark_achieved = $question_set_answers[$rank]['total_mark'];
                $email_info['user_email']= trim($question_set_answers[$rank]['user_profile']['email']);
                $email_info['time_taken'] = trim($question_set_answers[$rank]['time_taken']);
                $email_info['marks']= trim($question_set_answers[$rank]['total_mark']);
                $email_info['first_name']= trim($question_set_answers[$rank]['user_profile']['first_name']);
                $email_info['last_name']= trim($question_set_answers[$rank]['user_profile']['last_name']);
                $email_info['percentage']= ($mark_achieved/$total_mark)*100;
                $email_info['position']=$position+1;
                ///*************************** */
                // $this->out->writeln("Question set title : ".$email_info['question_set_title']);
                // $this->out->writeln("start_time         : ".$email_info['start_time']);
                // $this->out->writeln("end time           : ".$email_info['end_time']);
                // $this->out->writeln("assessment_time    : ".$email_info['assessment_time']);
                // $this->out->writeln("total_mark         : ".$email_info['total_mark']);
                // $this->out->writeln("Total Participant  : ".$email_info['number_of_participation']);
                // $this->out->writeln("Institution Name   : ".$email_info['institute_name']);
                // $this->out->writeln("total_time         : ".$email_info['total_time']);
                // $this->out->writeln("NUmber of candidates: ".$email_info['question_set_title']);
                // $this->out->writeln("NUmber of candidates: ".$email_info['question_set_title']);
                    
                // $this->out->writeln("User email         : ".$email_info['user_email']);
                // $this->out->writeln("Time Taken         : ".$email_info['time_taken']);
                // $this->out->writeln("Marks              : ".$email_info['marks']);
                // $this->out->writeln("First name         : ".$email_info['first_name']);
                // $this->out->writeln("Last Name          : ".$email_info['last_name']);
                // $this->out->writeln("Percentage         : ".$email_info['percentage']);
                // $this->out->writeln("Position           : ".$email_info['position']);
                ///***************** */ 
                try{
                    $this->out->writeln("*****************Dispatching job*****************");
                    StudentResultQueue::dispatch($email_info)->delay(now()->addSeconds($request['delay']));
                    $this->out->writeln("*****************Job Dispatched******************");
                }catch(\Exception $e){
                    $this->out->writeln("Mailing to \"".$email_info['user_email']."\" Unsuccessful! error: ".$e->getMessage());
                }
                if($rank+1<$total_student && $question_set_answers[$rank]['total_mark'] ==$question_set_answers[$rank+1]['total_mark'] && $question_set_answers[$rank]['time_taken']==$question_set_answers[$rank+1]['time_taken'])
                    continue;
                $position++;
            }
            return response()->json(['success'=>true, "message"=>"User will notify their result and Final-standings after a while"], $this->successStatus);
        }catch(\Exception $e){
            $this->out->writeln("Unable to Broadcast result! error: ".$e->getMessage());
            return response()->json(['success'=>false, "message"=>"Unable to Broadcast Result!", "error"=>$e->getMessage()], $this->failedStatus);
        }
    }
}
