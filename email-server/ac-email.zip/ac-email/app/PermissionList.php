<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PermissionList extends Model
{
    protected $table = 'permissions';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'guard_name'
    ];
}
